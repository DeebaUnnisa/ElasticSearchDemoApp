﻿using Nest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ElasticSearchDemoApp.Domain
{
    [ElasticsearchType(Name = "Meta_2017_1040_16_2F")]
    public class Meta_2017_1040_16_2F
    {
        //[Nested]
        //[PropertyName("DosArea")]
        //public List<Employee> Employees { get; set; }

        //[Number(Name = "DosArea")]
        //public string DosArea { get; set; }

     
    }
}
