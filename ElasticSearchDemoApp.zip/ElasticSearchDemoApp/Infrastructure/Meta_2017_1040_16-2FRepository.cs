﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ElasticSearchDemoApp.Domain;

namespace ElasticSearchDemoApp.Infrastructure
{
    public class Meta_2017_1040_16_2FRepository : IMeta_2017_1040_16_2FRepository
    {
        private readonly IElasticClientFactory _clientFactory;
        public Meta_2017_1040_16_2FRepository(IElasticClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }
        public IList<Meta_2017_1040_16_2F> Search()
        {
            var client = _clientFactory.CreateClient();
            var response = client.Search<Meta_2017_1040_16_2F>(s => s
            //.From(0)
            //.Size(10));
            .Query(q => q
        .Bool(b => b
            .Must(mu => mu
                .Match(m => m
                .Field(f => f.FADS.DosArea)
                    .Query(0);
            return response.Documents.ToList();
        }
    }
}
