﻿using ElasticSearchDemoApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ElasticSearchDemoApp.Infrastructure
{
    public interface IMeta_2017_1040_16_2FRepository
    {
        IList<Meta_2017_1040_16_2F> Search();
    }
}
