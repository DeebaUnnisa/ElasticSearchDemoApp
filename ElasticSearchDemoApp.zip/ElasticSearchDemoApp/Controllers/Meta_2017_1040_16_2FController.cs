﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ElasticSearchDemoApp.Domain;
using ElasticSearchDemoApp.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ElasticSearchDemoApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Meta_2017_1040_16_2FController : ControllerBase
    {
        private readonly ISearchRepository<Meta_2017_1040_16_2F> _repository;
        public Meta_2017_1040_16_2FController(ISearchRepository<Meta_2017_1040_16_2F> repository)
        {
            _repository = repository;
        }

        [HttpGet()]
        public IList<Meta_2017_1040_16_2F> GetMetadata([FromQuery]int from, [FromQuery]int size)
        {
            return _repository.Search("metadata", from, size);
        }
    }
}